# QSimSpace — Static Tensor-Network Backend (POC)

**One model:** 1D Transverse-Field Ising Model

`H = -J Σ Z_i Z_{i+1} - h Σ X_i`

This is the offline numerical backend for the QSimSpace internal-round POC.

### It demonstrates
- Matrix Product State (MPS) representation
- TEBD-style real-time evolution
- SVD bond truncation controlled by `chi`
- Exact sparse state-vector baseline
- Energy, entanglement entropy, fidelity
- Runtime and memory estimates
- A static JSON dataset for the HTML UI

### Repository layout
```text
QSimSpace/
├── backend/
│   └── generate_dataset.py
├── data/
│   └── tfim_results.json
├── tests/
│   └── test_backend.py
├── requirements.txt
└── README.md
```

### Run
```bash
pip install -r requirements.txt
python backend/generate_dataset.py
python tests/test_backend.py
```

The frontend can load `data/tfim_results.json` directly. No live API/server is needed for the POC.

### Deliberate scope
One equation/model + one tensor-network method (MPS + TEBD-style evolution) + one classical baseline. The dataset is precomputed offline so the browser stays simple.

### Note
For the small POC, the MPS is reconstructed into a full state vector only for validation/measurement. A later production version should compute observables directly from tensor contractions.
