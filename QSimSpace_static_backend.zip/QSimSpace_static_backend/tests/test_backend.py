
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "backend"))
from generate_dataset import generate_dataset

out = root / "data" / "_test.json"
ds = generate_dataset(out)
assert len(ds["cases"]) == 8
for c in ds["cases"]:
    assert c["n"] in (4, 8, 12)
    assert 0 <= c["mps"]["fidelity"] <= 1.000001
    assert len(c["mps"]["energy"]) == c["steps"]
    assert len(c["mps"]["entropy"]) == c["steps"]
out.unlink()
print("PASS")
