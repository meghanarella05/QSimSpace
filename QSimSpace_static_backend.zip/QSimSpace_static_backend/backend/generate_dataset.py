
from __future__ import annotations
import json
import time
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from scipy.sparse import kron, csr_matrix
from scipy.sparse.linalg import expm_multiply

I2 = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)

def one_site_gate(h, dt):
    return expm(1j * dt * h * X)

def two_site_gate(J, dt):
    return expm(1j * dt * J * np.kron(Z, Z)).reshape(2, 2, 2, 2)

def product_zero_mps(n):
    mps = []
    for _ in range(n):
        a = np.zeros((1, 2, 1), dtype=complex)
        a[0, 0, 0] = 1
        mps.append(a)
    return mps

def apply_one_site(mps, i, gate):
    a = mps[i]
    mps[i] = np.einsum("pq,aqb->apb", gate, a)

def apply_two_site(mps, i, gate, chi_max):
    a, b = mps[i], mps[i + 1]
    dl, _, dm = a.shape
    dm2, _, dr = b.shape
    assert dm == dm2

    theta = np.einsum("lpm,mqr->lpqr", a, b)
    theta = np.einsum("abpq,lpqr->lrab", gate, theta)
    mat = np.transpose(theta, (0, 2, 1, 3)).reshape(dl * 2, dr * 2)

    u, s, vh = np.linalg.svd(mat, full_matrices=False)
    keep = max(1, min(chi_max, np.count_nonzero(s > 1e-12)))
    u, s, vh = u[:, :keep], s[:keep], vh[:keep, :]
    s /= max(np.linalg.norm(s), 1e-15)

    mps[i] = u.reshape(dl, 2, keep)
    mps[i + 1] = (np.diag(s) @ vh).reshape(keep, 2, dr)

def mps_to_state(mps):
    state = mps[0]
    for a in mps[1:]:
        state = np.tensordot(state, a, axes=([-1], [0]))
    return state.reshape(-1)

def normalize_mps(mps):
    state = mps_to_state(mps)
    nrm = np.linalg.norm(state)
    if nrm > 0:
        mps[0] /= nrm

def entropy_at_cut(mps, cut):
    state = mps_to_state(mps).reshape(2 ** cut, -1)
    s = np.linalg.svd(state, compute_uv=False)
    p = s[s > 1e-12] ** 2
    p /= p.sum()
    return float(-np.sum(p * np.log2(p)))

def tfim_hamiltonian(n, J, h):
    H = csr_matrix((2**n, 2**n), dtype=complex)

    for i in range(n - 1):
        term = csr_matrix([[1]], dtype=complex)
        for site in range(n):
            term = kron(term, Z if site in (i, i + 1) else I2, format="csr")
        H -= J * term

    for i in range(n):
        term = csr_matrix([[1]], dtype=complex)
        for site in range(n):
            term = kron(term, X if site == i else I2, format="csr")
        H -= h * term

    return H.tocsr()

def exact_evolution(n, J, h, dt, steps):
    H = tfim_hamiltonian(n, J, h)
    state = np.zeros(2**n, dtype=complex)
    state[0] = 1
    energies = []
    start = time.perf_counter()

    for _ in range(steps):
        state = expm_multiply((-1j * dt) * H, state)
        state /= np.linalg.norm(state)
        energies.append(float(np.real(np.vdot(state, H @ state))))

    return state, energies, time.perf_counter() - start, H

def mps_evolution(n, J, h, chi, dt, steps, H):
    mps = product_zero_mps(n)
    x_gate = one_site_gate(h, dt)
    zz_gate = two_site_gate(J, dt)
    energies, entropy = [], []

    start = time.perf_counter()
    for _ in range(steps):
        for i in range(n):
            apply_one_site(mps, i, x_gate)
        for i in range(0, n - 1, 2):
            apply_two_site(mps, i, zz_gate, chi)
        for i in range(1, n - 1, 2):
            apply_two_site(mps, i, zz_gate, chi)

        normalize_mps(mps)
        state = mps_to_state(mps)
        energies.append(float(np.real(np.vdot(state, H @ state))))
        entropy.append(entropy_at_cut(mps, n // 2))

    return mps, energies, entropy, time.perf_counter() - start

def mps_memory_mb(mps):
    return sum(a.nbytes for a in mps) / (1024**2)

def exact_memory_mb(n):
    return (2**n * 16) / (1024**2)  # complex128

def run_case(n, J, h, chi, dt=0.05, steps=12):
    exact_state, exact_energy, exact_time, H = exact_evolution(n, J, h, dt, steps)
    mps, mps_energy, entropy, mps_time = mps_evolution(n, J, h, chi, dt, steps, H)
    mps_state = mps_to_state(mps)

    fidelity = float(abs(np.vdot(exact_state, mps_state))**2)
    error = abs(mps_energy[-1] - exact_energy[-1])

    return {
        "n": n, "J": J, "h": h, "chi": chi,
        "dt": dt, "steps": steps,
        "time": [round((i + 1) * dt, 6) for i in range(steps)],
        "mps": {
            "energy": [round(x, 10) for x in mps_energy],
            "entropy": [round(x, 10) for x in entropy],
            "runtime_ms": round(mps_time * 1000, 3),
            "memory_mb": round(mps_memory_mb(mps), 6),
            "fidelity": round(fidelity, 10),
            "final_energy_error": round(float(error), 10)
        },
        "exact": {
            "energy": [round(x, 10) for x in exact_energy],
            "runtime_ms": round(exact_time * 1000, 3),
            "memory_mb": round(exact_memory_mb(n), 6)
        }
    }

def generate_dataset(output_path):
    output_path = Path(output_path)
    cases = []
    for n, chis in [(4, [2, 4]), (8, [2, 4, 8]), (12, [2, 4, 8])]:
        for chi in chis:
            cases.append(run_case(n, 1.0, 0.5, chi))

    dataset = {
        "project": "QSimSpace",
        "model": "1D Transverse-Field Ising Model",
        "equation": "H = -J Σ Z_i Z_{i+1} - h Σ X_i",
        "method": "MPS + TEBD-style real-time evolution",
        "baseline": "Exact sparse state-vector evolution",
        "note": "Offline precomputed POC dataset for a static frontend.",
        "cases": cases
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(dataset, indent=2), encoding="utf-8")
    return dataset

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    path = root / "data" / "tfim_results.json"
    ds = generate_dataset(path)
    print(f"Wrote {len(ds['cases'])} cases to {path}")
